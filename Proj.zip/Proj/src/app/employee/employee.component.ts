import { Component } from '@angular/core';

declare var $: any; 

@Component({
  selector: 'app-emploee',
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent {
  
}
