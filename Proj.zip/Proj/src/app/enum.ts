export enum ESlotStatus {
    available, // 0
    occupied // 1
}